class Greet3
	@@name = "Ruby"  # class variable
	def initialize(salutation)
		@greeting = salutation
  end
	def to_s
		 "#{@greeting} from #{@@name}"
  end
end
x = Greet3.new "Bonjour"
puts x.to_s
