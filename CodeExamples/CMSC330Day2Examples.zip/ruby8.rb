class Greet2
	def initialize(salutation)
		@greeting = salutation
  end
	def display
		@greeting	# @instance variable
  end
end
x = Greet2.new("Bonjour")
puts x.display
