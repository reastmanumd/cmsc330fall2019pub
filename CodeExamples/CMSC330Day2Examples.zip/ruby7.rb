# ruby7.ruby
# Example class w/ instance method
class Greet1	# class names capitalized
	def to_s
      "Hi"
  end
end
x = Greet1.new
puts x.to_s
