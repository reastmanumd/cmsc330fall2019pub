# ruby4.rb
def abs(x)
  (-x) if x < 0
  x  # need this? Try without
end

puts abs(-4)
