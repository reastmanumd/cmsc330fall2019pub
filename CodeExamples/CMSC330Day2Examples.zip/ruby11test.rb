# ruby11test.rb
load 'ruby11.rb'
puts Person.displayCount
# gives 0
p1 = Person.new("Ann")
p2 = Person.new("Bill")
puts Person.displayCount
# gives 2
