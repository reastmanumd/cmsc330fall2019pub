class Greet4
	@@name = "Ruby"
	def self.name	# class method
		puts @@name
  	end
end
Greet4.name
