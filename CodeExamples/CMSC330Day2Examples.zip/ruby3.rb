# ruby3.rb
def factorial(m)
  x = 1
  n = 1
  while n <= m
    x = x * n
    n = n + 1
  end
  x  # return is optional!
end

puts factorial 6 # so are ()
