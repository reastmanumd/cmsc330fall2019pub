# ruby11.rb
class Person
  @@count = 0
  def initialize(name)
    @name = name; @@count+=1 
  end
  def to_s
    @name
  end
  def self.displayCount
    @@count 
  end
end
