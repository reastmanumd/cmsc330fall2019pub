# ruby12.rb
class Student < Person
  def initialize(name, major)
    @name = name
    @major = major
  end
  def to_s 
    super + @major
  end
end
