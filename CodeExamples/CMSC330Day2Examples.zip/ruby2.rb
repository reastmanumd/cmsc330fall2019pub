# ruby2.rb
x = 1
n = 5
while n <= 5
  x = x * n
  n = n + 1
end
print(x)
print("\n")