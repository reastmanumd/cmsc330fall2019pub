# ruby1.rb
puts “Hello Ruby” 
