# Class examples
(1..3).class
Range

1.class
Fixnum

Range.class
Class

[1,3,4].class
Array
