# ruby5.rb
def factorial(m)
  x = 1
  for n in (1..m)
    x = x * n
  end
  x  
end

puts factorial 6 # so are ()
