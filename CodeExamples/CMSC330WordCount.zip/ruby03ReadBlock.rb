# ruby03ReadBlock.rb
# Read file with code block
# Ruby style
f1 = File.open("dataFiles/poem.txt","r")
# Reads all lines into memory
f1.readlines.each {|line| puts line }

# Alternative that doesn't read all 
# lines into an array first
# Reads one by one
#f1.each_line {|line| puts line }