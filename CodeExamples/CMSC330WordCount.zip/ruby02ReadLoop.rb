# ruby02ReadLines.rb
# Read file with loop and eof? 
# Java style
f1 = File.open("dataFiles/poem.txt","r")
until f1.eof?
  line = f1.gets #readline works too
  puts line
end