
This set of files shows incremental development of a Ruby program to read a text file and produce a sorted frequency table of words. 

Each Ruby file shows a stage in the development of the program, from simply opening the file, to reading lines, to counting all words, to filtering punctutation from words, to creating the frequency table. 

The point of this exercise is to encourage you to follow a similar pattern in your own coding for projects. Code a step at a time, each step doing something that can be checked.  And save the intermediate steps, either in separate file or a single log file. 

For text files, the web site Project Guttenberg

https://www.gutenberg.org/

gives a large collection of public domain books saved in multiple formats, including ASCII, that you can use for analysis.


R. Eastman
Fall 2019