# main.rb
# Option: Dynamic file entry
##puts "Enter file"
##fileName = gets
##load fileName.strip
# Option: Commet out unused files
#load 'ruby1OpenFile.rb'
#load 'ruby02ReadLines.rb'
#load 'ruby03ReadBlock.rb'
#load 'ruby04CountLines.rb'
#load 'ruby05CountWords.rb'
#load 'ruby06FilterWords.rb'
#load 'ruby07HashWords.rb'
load 'ruby8ClassVersion.rb'

