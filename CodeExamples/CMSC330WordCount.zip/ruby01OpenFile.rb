# ruby1OpenFile.rb
# Experiment with opening file
# 
f1 = File.open("dataFiles/poem.txt","r")
# Angle brackets help detect newlines
puts ">" + f1.gets + "<"
# Tried alternatives
#puts f1.readline
#puts f1.readlines
