# ruby06FilterWords.rb
# Strip punctuation from each word
# Take each to lower case
f1 = File.open("dataFiles/poem.txt","r")
f1.readlines.each do |line|  
  line.split.each do |word| 
       puts word.tr("',.","").downcase
  end
end

