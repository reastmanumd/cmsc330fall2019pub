# ruby07HashWords
# Use hash table to create word frequency
# Print raw and sorted table
f1 = File.open("dataFiles/poem.txt","r")
wordList = Hash.new(0)
punc = "',.?!-'\""
f1.readlines.each do |line|  
  line.split.each do |word| 
       w = word.tr(punc,"").downcase
       wordList[w] = wordList[w] + 1 if w != ""
  end
end
puts wordList
wordList.sort.each { |key, value| puts "(#{key},#{value})"}

# Remaining to do - skip comment lines w/ #