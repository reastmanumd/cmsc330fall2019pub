# ruby04CountLines.rb
# Count number of lines
# with code block
f1 = File.open("dataFiles/poem.txt","r")
lineCount = 0
f1.readlines.each {|line| lineCount+=1 }
puts lineCount
