# ruby08ClassVersion
# Convert to 
# Use hash table to create word frequency
# Print raw and sorted table
class WordTable
   @@punc = "',.?!-'\""
   def initialize
     @wordList = Hash.new(0)
   end
   def display 
     @wordList.sort.each { |key, value| puts "(#{key},#{value})"}
   end 
   private
   def cleanWord(word)
     word.tr(@@punc,"").downcase
   end
   public
   def addWord(w)
    w = cleanWord(w)
    @wordList[w] = @wordList[w] + 1 if w != ""
   end 
end

f1 = File.open("dataFiles/poem.txt","r")
table = WordTable.new
f1.readlines.each do |line|  
  line.split.each do |word| 
    table.addWord(word)
  end
end
table.display

