# ruby05CountWords.rb
# Count # of words with split
# Using do end code block
f1 = File.open("dataFiles/poem.txt","r")
wordCount = 0
f1.readlines.each do 
  # First see if split works right
  #  |line| puts line.split
  |line| line.split.each { wordCount+= 1 }
end
puts wordCount
